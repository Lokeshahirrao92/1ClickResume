import React from 'react';
import ResumeForm from './components/ResumeForm';
import ResumePreview from './components/ResumePreview';
import './index.css';

function App() {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    phone: '',
    summary: '',
    experience: '',
    education: '',
    skills: '',
  });

  return (
    <div className="app">
      <h1 className="title">1ClickResume</h1>
      <div className="container">
        <ResumeForm formData={formData} setFormData={setFormData} />
        <ResumePreview formData={formData} />
      </div>
    </div>
  );
}

export default App;
