import React from 'react';

const ResumePreview = ({ formData }) => {
  return (
    <div className="preview-section">
      <h2>Resume Preview</h2>
      <div className="resume-box">
        <h3>{formData.name}</h3>
        <p>{formData.email} | {formData.phone}</p>
        <p><strong>Summary:</strong> {formData.summary}</p>
        <p><strong>Experience:</strong> {formData.experience}</p>
        <p><strong>Education:</strong> {formData.education}</p>
        <p><strong>Skills:</strong> {formData.skills}</p>
      </div>
    </div>
  );
};

export default ResumePreview;
