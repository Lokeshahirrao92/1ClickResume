import React from 'react';

const ResumeForm = ({ formData, setFormData }) => {
  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="form-section">
      <h2>Enter Details</h2>
      {['name', 'email', 'phone', 'summary', 'experience', 'education', 'skills'].map(field => (
        <div key={field}>
          <label>{field.toUpperCase()}</label>
          <textarea name={field} value={formData[field]} onChange={handleChange} />
        </div>
      ))}
    </div>
  );
};

export default ResumeForm;
