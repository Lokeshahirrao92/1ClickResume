# 1ClickResume

🚀 A modern, no-code Resume Builder using React + Vite.

## Features
- Fill your details and generate resume instantly.
- Edit before finalizing.
- Preview before download.
- Share via WhatsApp.
- Responsive design.

## Getting Started

```bash
npm install
npm run dev
